package microservices.helper.idempotency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdempotentOperationServiceApplicationTests {

    @Test
    void contextLoads() {
    }
}
